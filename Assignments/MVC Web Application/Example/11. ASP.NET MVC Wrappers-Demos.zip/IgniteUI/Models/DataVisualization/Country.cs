﻿namespace IgniteUI.Models.DataVisualization
{
    public class Country
    {
        public string Name { get; set; }

        public int Pop1995 { get; set; }

        public int Pop2005 { get; set; }

        public int Pop2015 { get; set; }

        public int Pop2025 { get; set; }
    }
}