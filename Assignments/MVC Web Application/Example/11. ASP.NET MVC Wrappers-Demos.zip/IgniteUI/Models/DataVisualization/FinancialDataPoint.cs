﻿namespace IgniteUI.Models.DataVisualization
{
    public class FinancialDataPoint
    {
        public string Label { get; set; }

        public double Spending { get; set; }

        public double Budget { get; set; }
    }
}