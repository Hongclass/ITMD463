﻿namespace IgniteUI.Models
{
    using System.Web;

    public class FileUploadInputModel
    {
        public string Name { get; set; }

        public HttpPostedFile Picture { get; set; }
    }
}