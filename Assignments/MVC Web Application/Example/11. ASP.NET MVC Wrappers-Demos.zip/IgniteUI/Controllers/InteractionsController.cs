﻿namespace IgniteUI.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;

    using IgniteUI.Models.DataVisualization;

    public class InteractionsController : Controller
    {
        public ActionResult FileUpload()
        {
            return View();
        }

        [HttpPost]
        public ActionResult FileUpload(HttpPostedFile pictureUpload)
        {
            return null;
        }

        public ActionResult Tree()
        {
            var categoreis = new List<ProductCategory>()
            {
                new ProductCategory {Id = 1, Name = "C#", Products = new List<Product>
                {
                    new Product() { Id = 1, Name = "ASP.NET MVC" },
                    new Product() { Id = 2, Name = "ASP.NET Web API" },
                    new Product() { Id = 3, Name = "ASP.NET Web Forms" },
                }},
                new ProductCategory {Id = 2, Name = "Java"},
                new ProductCategory {Id = 3, Name = "PHP"},
                new ProductCategory {Id = 4, Name = "JavaScript", Products = new List<Product>
                {
                    new Product() { Id = 1, Name = "Angular" },
                    new Product() { Id = 2, Name = "TypeScript" },
                    new Product() { Id = 3, Name = "NodeJS" },
                    new Product() { Id = 3, Name = "NativeScript" },
                }},
                new ProductCategory {Id = 5, Name = "Python"},
                new ProductCategory {Id = 6, Name = "Ruby"},
                new ProductCategory {Id = 7, Name = "Lisp"},
            }.AsQueryable();

            return this.View(categoreis);
        }

        public ActionResult Rating()
        {
            return this.View();
        }

        public ActionResult Popover()
        {
            return this.View();
        }
    }
}