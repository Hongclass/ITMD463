﻿namespace IgniteUI.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    using IgniteUI.Models.DataVisualization;

    using Infragistics.Web.Mvc;

    public class EditorsController : Controller
    {
        public ActionResult ComboBox()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ComboBox(Product model)
        {
            return null;
        }

        public ActionResult GetCategories()
        {
            var categories = new List<ProductCategory>
            {
                new ProductCategory { Id = 1, Name = "Food" },
                new ProductCategory { Id = 2, Name = "Clothes" },
                new ProductCategory { Id = 3, Name = "Shoes" },
                new ProductCategory { Id = 4, Name = "Electronics" },
                new ProductCategory { Id = 5, Name = "IT" },
                new ProductCategory { Id = 6, Name = "Watches" },
                new ProductCategory { Id = 7, Name = "Drinks" }
            };

            return this.Json(categories.AsQueryable(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult HtmlEditor()
        {
            return View();
        }

        public ActionResult DatePicker()
        {
            return View();
        }
    }
}