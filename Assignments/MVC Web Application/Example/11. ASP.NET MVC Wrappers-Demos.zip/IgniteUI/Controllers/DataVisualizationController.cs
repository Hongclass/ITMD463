﻿namespace IgniteUI.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    using IgniteUI.Models.DataVisualization;
    using System;

    public class DataVisualizationController : Controller
    {
        /// <summary>
        ///     TODO: Fix the data chart
        /// </summary>
        /// <returns></returns>
        public ActionResult DataChart()
        {
            var data = new List<Country>()
            {
                new Country { Name = "China", Pop1995 = 1216, Pop2005 = 1297, Pop2015 = 1361, Pop2025 = 1394 },
                new Country { Name = "India", Pop1995 = 920, Pop2005 = 1090, Pop2015 = 1251, Pop2025 = 1396 },
                new Country { Name = "United States", Pop1995 = 266, Pop2005 = 295, Pop2015 = 322, Pop2025 = 351 },
                new Country { Name = "Indonesia", Pop1995 = 197, Pop2005 = 229, Pop2015 = 256, Pop2025 = 277 },
                new Country { Name = "Brazil", Pop1995 = 161, Pop2005 = 186, Pop2015 = 204, Pop2025 = 218 }
            }.AsQueryable();

            return this.View(data);
        }

        public ActionResult PieChart()
        {
            return this.View(this.GetPieChartData());
        }

        public ActionResult RadialGauge()
        {
            return this.View();
        }

        public ActionResult Sparkline()
        {
            return this.View(this.GetSparklineData());
        }

        /// <summary>
        ///     TODO: Fix the map
        /// </summary>
        /// <returns></returns>
        public ActionResult Map()
        {
            return this.View(this.GetMapData());
        }

        public ActionResult Barcode()
        {
            return this.View();
        }

        private IQueryable<FinancialDataPoint> GetPieChartData()
        {
            return new List<FinancialDataPoint>()
            {
                new FinancialDataPoint { Spending = 20, Budget = 60, Label = "Administration", },
                new FinancialDataPoint { Spending = 80, Budget = 40, Label = "Sales", },
                new FinancialDataPoint { Spending = 20, Budget = 60, Label = "IT", },
                new FinancialDataPoint { Spending = 80, Budget = 40, Label = "Marketing", },
                new FinancialDataPoint { Spending = 20, Budget = 60, Label = "Development", },
                new FinancialDataPoint { Spending = 60, Budget = 20, Label = "Customer Support", },
            }.AsQueryable();
        }

        private IQueryable<Product> GetSparklineData()
        {
            var rand = new Random();
            var products = new List<Product>();
            for (int i = 0; i < 200; i++)
            {
                products.Add(new Product() { Name = "Product" + i, Price = rand.Next(1, 5000) });
            }

            return products.AsQueryable();
        }

        private IQueryable<Capital> GetMapData()
        {
            var capitals = new List<Capital>();

            capitals.Add(new Capital { Name = "Warsaw", Country = "Poland", Latitude = 52.21, Longitude = 21 });
            capitals.Add(new Capital { Name = "London", Country = "England", Latitude = 51.50, Longitude = 0.12 });
            capitals.Add(new Capital { Name = "Berlin", Country = "Germany", Latitude = 52.50, Longitude = 13.33 });
            capitals.Add(new Capital { Name = "Moscow", Country = "Russia", Latitude = 55.75, Longitude = 37.51 });
            capitals.Add(new Capital { Name = "Sydney", Country = "Australia", Latitude = -33.83, Longitude = 151.2 });
            capitals.Add(new Capital { Name = "Tokyo", Country = "Japan", Latitude = 35.6895, Longitude = 139.6917 });
            capitals.Add(new Capital { Name = "Seoul", Country = "South Korea", Latitude = 37.5665, Longitude = 126.9780 });
            capitals.Add(new Capital { Name = "Delhi", Country = "India", Latitude = 28.6353, Longitude = 77.2250 });
            capitals.Add(new Capital { Name = "Mumbai", Country = "India", Latitude = 19.0177, Longitude = 72.8562 });
            capitals.Add(new Capital { Name = "Manila", Country = "Philippines", Latitude = 14.6010, Longitude = 120.9762 });
            capitals.Add(new Capital { Name = "Shanghai", Country = "China", Latitude = 31.2244, Longitude = 121.4759 });
            capitals.Add(new Capital { Name = "Mexico City", Country = "Mexico", Latitude = 19.4270, Longitude = -99.1276 });
            capitals.Add(new Capital { Name = "New York", Country = "United States", Latitude = 40.7561, Longitude = -73.9870 });
            capitals.Add(new Capital { Name = "Sao Paulo", Country = "Brasil", Latitude = -23.5489, Longitude = -46.6388 });
            capitals.Add(new Capital { Name = "Los Angeles", Country = "United States", Latitude = 34.0522, Longitude = -118.2434 });
            capitals.Add(new Capital { Name = "Sofia", Country = "Bulgaria", Latitude = 42.697845, Longitude = 23.321925 });

            return capitals.AsQueryable();
        }
    }
}