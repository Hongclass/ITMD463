﻿namespace IgniteUI.Controllers
{
    using System.Web.Mvc;

    using System.Collections.Generic;
    using System.Linq;

    using IgniteUI.Models;

    using Infragistics.Web.Mvc;

    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return this.View();
        }
 
    }
}