﻿namespace IgniteUI.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    using IgniteUI.Models;

    using Infragistics.Web.Mvc;

    public class GridController : Controller
    {
        public ActionResult WithGridModel()
        {
            var model = new GridModel { DataSource = this.GetData() };

            return this.View(model);
        }

        public ActionResult WithIQueryable()
        {
            return this.View(this.GetData());
        }

        public ActionResult WithIQueryableSettins()
        {
            return this.View(this.GetData());
        }

        private IQueryable<RegisterViewModel> GetData()
        {
            var pesho = new List<RegisterViewModel>
            {
                new RegisterViewModel
                {
                    ConfirmPassword = "qwerty",
                    Password = "qwerty",
                    Email = "vlado@softuni.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "123321",
                    Password = "123321",
                    Email = "alex@softuni.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "iojoasld",
                    Password = "iojoasld",
                    Email = "nakov@softuni.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "awwd21312",
                    Password = "awwd21312",
                    Email = "nasko@softuni.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "adwd213123",
                    Password = "adwd213123",
                    Email = "petya@softuni.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "adwd213123",
                    Password = "adwd213123",
                    Email = "gosho@softuni.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "adwd213123",
                    Password = "adwd213123",
                    Email = "minka@abv.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "adwd213123",
                    Password = "adwd213123",
                    Email = "stavri@gmail.com"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "adwd213123",
                    Password = "adwd213123",
                    Email = "jivko@mail.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "adwd213123",
                    Password = "adwd213123",
                    Email = "dodo@dodov.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "adwd213123",
                    Password = "adwd213123",
                    Email = "tanya@pencheva.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "adwd213123",
                    Password = "adwd213123",
                    Email = "petya@grozdarska.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "adwd213123",
                    Password = "adwd213123",
                    Email = "kiko@gmail.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "adwd213123",
                    Password = "adwd213123",
                    Email = "acho@softuni.bg"
                },
                new RegisterViewModel
                {
                    ConfirmPassword = "adwd213123",
                    Password = "adwd213123",
                    Email = "bogi@softuni.bg"
                }
            };

            return pesho.AsQueryable();
        }
    }
}