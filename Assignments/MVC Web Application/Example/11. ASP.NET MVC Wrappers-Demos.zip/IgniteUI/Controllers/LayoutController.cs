﻿namespace IgniteUI.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    using IgniteUI.Models.DataVisualization;

    public class LayoutController : Controller
    {
        public ActionResult TileManager()
        {
            var capitals = this.GetMapData();
            return View(capitals);
        }

        public ActionResult Splitter()
        {
            return View();
        }


        private IQueryable<Capital> GetMapData()
        {
            var capitals = new List<Capital>();

            capitals.Add(new Capital { Name = "Warsaw", Country = "Poland", Latitude = 52.21, Longitude = 21 });
            capitals.Add(new Capital { Name = "London", Country = "England", Latitude = 51.50, Longitude = 0.12 });
            capitals.Add(new Capital { Name = "Berlin", Country = "Germany", Latitude = 52.50, Longitude = 13.33 });
            capitals.Add(new Capital { Name = "Moscow", Country = "Russia", Latitude = 55.75, Longitude = 37.51 });
            capitals.Add(new Capital { Name = "Sydney", Country = "Australia", Latitude = -33.83, Longitude = 151.2 });
            capitals.Add(new Capital { Name = "Tokyo", Country = "Japan", Latitude = 35.6895, Longitude = 139.6917 });
            capitals.Add(new Capital { Name = "Seoul", Country = "South Korea", Latitude = 37.5665, Longitude = 126.9780 });
            capitals.Add(new Capital { Name = "Delhi", Country = "India", Latitude = 28.6353, Longitude = 77.2250 });
            capitals.Add(new Capital { Name = "Mumbai", Country = "India", Latitude = 19.0177, Longitude = 72.8562 });
            capitals.Add(new Capital { Name = "Manila", Country = "Philippines", Latitude = 14.6010, Longitude = 120.9762 });
            capitals.Add(new Capital { Name = "Shanghai", Country = "China", Latitude = 31.2244, Longitude = 121.4759 });
            capitals.Add(new Capital { Name = "Mexico City", Country = "Mexico", Latitude = 19.4270, Longitude = -99.1276 });
            capitals.Add(new Capital { Name = "New York", Country = "United States", Latitude = 40.7561, Longitude = -73.9870 });
            capitals.Add(new Capital { Name = "Sao Paulo", Country = "Brasil", Latitude = -23.5489, Longitude = -46.6388 });
            capitals.Add(new Capital { Name = "Los Angeles", Country = "United States", Latitude = 34.0522, Longitude = -118.2434 });
            capitals.Add(new Capital { Name = "Sofia", Country = "Bulgaria", Latitude = 42.697845, Longitude = 23.321925 });

            return capitals.AsQueryable();
        }
    }
}