﻿namespace IgniteUI.Crud.Controllers
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    using IgniteUI.Crud.Models;

    using Infragistics.Web.Mvc;

    using Newtonsoft.Json;

    public class PeopleController : Controller
    {
        private ApplicationDbContext db;

        public PeopleController()
        {
            this.db = new ApplicationDbContext();
        }

        [GridDataSourceAction]
        public ActionResult Index()
        {
            var people = db.People.OrderBy(x => x.Name);
            return this.View(this.GetData());
        }
        
        public ActionResult Create()
        {
            return null;
        }

        public ActionResult Update(string ig_transactions)
        {
            ArrayList transactions = (ArrayList) JsonConvert.DeserializeObject(ig_transactions);
            var people = db.People;

            return null;
        }

        public ActionResult Remove(int id)
        {
            return null;   
        }

        private IQueryable<PersonViewModel> GetData()
        {
            var pesho = new List<PersonViewModel>
            {
                new PersonViewModel
                {
                    Id = 1,
                    Name = "Pesho",
                    Age = 12,
                    BirthDate = new DateTime(1999, 12, 2)
                },
                new PersonViewModel
                {
                    Id = 2,
                    Name = "Minka",
                    Age = 12,
                    BirthDate = new DateTime(1878, 11, 5)
                },
                new PersonViewModel
                {
                    Id = 3,
                    Name = "Goshka",
                    Age = 12,
                    BirthDate = new DateTime(1999, 12, 2)
                },
                new PersonViewModel
                {
                    Id = 4,
                    Name = "Trytka",
                    Age = 12,
                    BirthDate = new DateTime(1999, 12, 2)
                },
                new PersonViewModel
                {
                    Id = 5,
                    Name = "Bilka",
                    Age = 12,
                    BirthDate = new DateTime(1999, 12, 2)
                },
                new PersonViewModel
                {
                    Id = 6,
                    Name = "Merda",
                    Age = 12,
                    BirthDate = new DateTime(1999, 12, 2)
                },
                new PersonViewModel
                {
                    Id = 7,
                    Name = "Stamat",
                    Age = 12,
                    BirthDate = new DateTime(1999, 12, 2)
                },
                new PersonViewModel
                {
                    Id = 8,
                    Name = "Grozdyo",
                    Age = 12,
                    BirthDate = new DateTime(1999, 12, 2)
                },
                new PersonViewModel
                {
                    Id = 9,
                    Name = "Siyka",
                    Age = 12,
                    BirthDate = new DateTime(1999, 12, 2)
                },
                new PersonViewModel
                {
                    Id = 10,
                    Name = "Zdravka",
                    Age = 12,
                    BirthDate = new DateTime(1999, 12, 2)
                },
            };

            return pesho.AsQueryable();
        }

    }
}