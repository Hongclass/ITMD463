﻿namespace IgniteUI.Crud.Models
{
    using System;

    public class PersonViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int Age { get; set; }

        public DateTime BirthDate { get; set; }
    }
}