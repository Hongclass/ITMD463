﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(IgniteUI.Crud.Startup))]
namespace IgniteUI.Crud
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
