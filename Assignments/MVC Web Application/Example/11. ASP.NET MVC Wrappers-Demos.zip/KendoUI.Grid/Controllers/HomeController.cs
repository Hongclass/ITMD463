﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KendoUI.Grid.Controllers
{
    using System.Data.Entity;

    using Kendo.Mvc.Extensions;
    using Kendo.Mvc.UI;

    using KendoUI.Grid.Models;

    using Newtonsoft.Json;

    public class HomeController : Controller
    {
        private ApplicationDbContext db;

        public HomeController()
        {
            this.db = new ApplicationDbContext();
        }

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Read([DataSourceRequest] DataSourceRequest request)
        {
            var data = this.db.People;
            return this.Json(data.ToDataSourceResult(request));
        }

        [HttpPost]
        public ActionResult Create([DataSourceRequest] DataSourceRequest request, Person model)
        {
            if (model != null && this.ModelState.IsValid)
            {
                var itemForAdding = db.Entry(model);
                itemForAdding.State = EntityState.Added;
                this.db.SaveChanges();
            }

            return this.Json(new[] { model }.ToDataSourceResult(request, this.ModelState));
        }

        [HttpPost]
        public ActionResult Update([DataSourceRequest] DataSourceRequest request, Person model)
        {
            if (model != null && this.ModelState.IsValid)
            {
                var person = this.db.People.Find(model.Id);
                person.Name = model.Name;
                person.Age = model.Age;
                person.BirthDate = model.BirthDate;
                this.db.SaveChanges();
            }

            return this.Json(new[] { model }.ToDataSourceResult(request, this.ModelState));
        }

        public ActionResult Delete([DataSourceRequest] DataSourceRequest request, Person model)
        {
            var person = this.db.Entry(model);
            person.State = EntityState.Deleted;
            this.db.SaveChanges();

            return this.Json(new[] { model }.ToDataSourceResult(request, this.ModelState));
        }
    }
}