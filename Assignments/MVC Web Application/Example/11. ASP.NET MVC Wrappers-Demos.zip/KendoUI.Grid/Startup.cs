﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(KendoUI.Grid.Startup))]
namespace KendoUI.Grid
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
