﻿namespace Bookmarks.Common.Mappings
{
    public interface IMapTo<T>
    {
    }
}
