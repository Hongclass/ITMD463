﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASP.NET_MVC_5_Demos
{
    public class AppSettings
    {
        public string SiteTitle { get; set; }
    }
}
