﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASP.NET_MVC_Essentials_Demo.Models
{
    class DisplayNameAttribute : Attribute
    {
    }
}
