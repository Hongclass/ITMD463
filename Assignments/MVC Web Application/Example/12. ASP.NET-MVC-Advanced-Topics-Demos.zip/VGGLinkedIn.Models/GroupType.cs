﻿namespace VGGLinkedIn.Data.Models
{
    public enum GroupType
    {
        Professional,
        Networking,
        NonProfit,
        Conference,
        Corporate
    }
}
