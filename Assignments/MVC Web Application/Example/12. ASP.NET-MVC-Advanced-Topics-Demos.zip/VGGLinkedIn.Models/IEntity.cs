﻿namespace VGGLinkedIn.Models
{
    public interface IEntity
    {
    }
}
