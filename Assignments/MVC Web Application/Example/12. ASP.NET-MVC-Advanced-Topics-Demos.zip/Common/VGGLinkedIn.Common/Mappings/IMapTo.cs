﻿namespace VGGLinkedIn.Common.Mappings
{
    public interface IMapTo<T>
    {
    }
}
