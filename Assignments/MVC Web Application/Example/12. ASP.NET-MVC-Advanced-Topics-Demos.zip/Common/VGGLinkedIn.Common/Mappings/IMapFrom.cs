﻿namespace VGGLinkedIn.Common.Mappings
{
    public interface IMapFrom<T>
    {
    }
}
