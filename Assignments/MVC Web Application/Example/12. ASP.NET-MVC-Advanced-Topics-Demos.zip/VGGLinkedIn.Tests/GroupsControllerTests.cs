﻿namespace VGGLinkedIn.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using TestStack.FluentMVCTesting;

    using VGGLinkedIn.Web.Controllers;
    using VGGLinkedIn.Data;
    using VGGLinkedIn.Web.Infrastructure.CacheService;

    [TestClass]
    public class GroupsControllerTests
    {
        [TestMethod]
        public void TestIndexAction_ShouldReturnDefaultView()
        {
            var data = new VggLinkedInData(new VggLinkedInContext());
            var controller = new GroupsController(data, new MemoryCacheService(data));
            controller.WithCallTo(x => x.Index())
                .
                .ShouldRenderDefaultView();
        }
    }
}
