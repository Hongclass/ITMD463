﻿namespace CSRF_Example.Models
{
    using Microsoft.AspNet.Identity.EntityFramework;

    public class ApplicationUser : User
    {  
    }
}