﻿namespace SportSystem.Common.Mappings
{
    public interface IMapTo<T>
    {
    }
}
