﻿namespace SportSystem.Common.Mappings
{
    public interface IMapFrom<T>
    {
    }
}