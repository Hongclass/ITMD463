﻿namespace SportSystem.WebApp.InputModels
{
    public class MatchBetInputModel
    {
        public int MatchId { get; set; }

        public string UserId { get; set; }
    }
}