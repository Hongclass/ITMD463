﻿namespace SportSystem.WebApp.InputModels
{
    public class VoteInputModel
    {
        public int TeamId { get; set; }
    }
}