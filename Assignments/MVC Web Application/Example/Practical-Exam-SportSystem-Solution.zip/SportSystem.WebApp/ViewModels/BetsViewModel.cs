﻿namespace SportSystem.WebApp.ViewModels
{
    public class BetsViewModel
    {
        public decimal HomeBets { get; set; }

        public decimal AwayBets { get; set; }
    }
}