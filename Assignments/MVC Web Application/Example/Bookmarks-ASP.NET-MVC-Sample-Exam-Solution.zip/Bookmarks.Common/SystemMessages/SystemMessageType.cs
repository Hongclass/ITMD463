﻿namespace Bookmarks.Common.SystemMessages
{
    public enum SystemMessageType
    {
        Information,
        Success,
        Warning,
        Error,
    }
}
