﻿namespace Bookmarks.Common.SystemMessages
{
    public class SystemMessage
    {
        public string Content { get; set; }

        public SystemMessageType Type { get; set; }
    }
}
