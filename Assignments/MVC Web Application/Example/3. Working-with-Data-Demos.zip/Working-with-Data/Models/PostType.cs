﻿namespace Scaffolding.Models
{
    public enum PostType
    {
        BlogPost,
        NewsPost,
        ShopPost
    }
}