﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bug2Bug.Logic
{
    public class ShoppingCart
    {
    }
}